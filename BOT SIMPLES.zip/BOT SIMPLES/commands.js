const { 
default: 
makeWASocket, 
useMultiFileAuthState,
fetchLatestBaileysVersion 
} = require('@whiskeysockets/baileys');

const { fetchJson, getBuffer } = require("./arquivos/functions.js");

const readline = require("readline");
const colors = require("colors");
const P = require('pino');
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

async function CarisysBot() {
var salvarqr = "./assets/qr-code";
const { state, saveCreds } = await useMultiFileAuthState(salvarqr);
const { version } = await fetchLatestBaileysVersion();

const carisys = makeWASocket({
version,
auth: state,
printQRInTerminal: false, 
logger: P({ level: 'silent' }),
browser: ['Ubuntu', 'Edge', '110.0.1587.56'],
});

if (!carisys.authState.creds.registered) {
try {
const askNumber = () => {
return new Promise((resolve) => {
rl.question(colors.cyan("Digite seu número do WhatsApp:\nExemplo: +559681361714:\n "), (number) => {
resolve(number);
});
});
};

const number = await askNumber();
const cleanNumber = number.replace(/[^0-9]/g, "");
let code = await carisys.requestPairingCode(cleanNumber);
code = code?.match(/.{1,4}/g)?.join("-") || code;
console.log(colors.green(`Código de pareamento: `) + colors.white(code));
rl.close();
} catch (error) {
console.error(colors.red("Erro ao solicitar o código de pareamento:"), error);
}
}

carisys.ev.on('messages.upsert', async (message) => {
const msg = message.messages[0];
const info = msg;
const type = msg.message ? Object.keys(msg.message)[0] : null;

const body = info.message?.conversation || info.message?.viewOnceMessageV2?.message?.imageMessage?.caption || info.message?.viewOnceMessageV2?.message?.videoMessage?.caption || info.message?.imageMessage?.caption || info.message?.videoMessage?.caption || info.message?.extendedTextMessage?.text || info.message?.viewOnceMessage?.message?.videoMessage?.caption || info.message?.viewOnceMessage?.message?.imageMessage?.caption || info.message?.documentWithCaptionMessage?.message?.documentMessage?.caption || info.message?.buttonsMessage?.imageMessage?.caption || info.message?.buttonsResponseMessage?.selectedButtonId || info.message?.templateButtonReplyMessage?.selectedId || info?.text || info.message?.editedMessage?.message?.protocolMessage?.editedMessage?.extendedTextMessage?.text || info.message?.editedMessage?.message?.protocolMessage?.editedMessage?.imageMessage?.caption || info.message.interactiveMessage?.body || JSON.parse(info.message?.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson || '{}')?.id || info?.text || '';

const Procurar_String = info.message?.conversation || info.message?.viewOnceMessageV2?.message?.imageMessage?.caption || info.message?.viewOnceMessageV2?.message?.videoMessage?.caption || info.message?.imageMessage?.caption || info.message?.videoMessage?.caption || info.message?.extendedTextMessage?.text || info.message?.viewOnceMessage?.message?.videoMessage?.caption || info.message?.viewOnceMessage?.message?.imageMessage?.caption || info.message?.documentWithCaptionMessage?.message?.documentMessage?.caption || info.message?.buttonsMessage?.imageMessage?.caption || "";

const PR_String = Procurar_String.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, "");
const args = body.trim().split(/ +/).slice(1);
const argss = body.split(/ +/g);
const arg = body.substring(body.indexOf(' ') + 1);
const budy = (type === 'conversation') ? info.message?.conversation : (type === 'extendedTextMessage') ? info.message?.extendedTextMessage?.text : '';

const from = msg.key.remoteJid;

//DEFINE O PREFIXO! 
if (body.startsWith('!')) {
//
const command = body.slice(1).split(' ')[0].toLowerCase();
const q = args.join(' '); 

//COMANDOS SAO ADICONADO ABAIXO! 
switch (command) {
case 'playaudio':
case 'playaud':
if (!q) return carisys.sendMessage(from, { text: `Informe o nome da música` }, { quoted: info });
try {
carisys.sendMessage(from, { text: `Baixando o áudio solicitado...` }, { quoted: info });
await carisys.sendMessage(from, { audio: { url: `https://carisys.online/api/downloads/youtube/play_audio?query=${encodeURIComponent(q)}` }, mimetype: "audio/mpeg" }, { quoted: info});
} catch (erro) {
console.error(erro);
carisys.sendMessage(from, { text: `Ocorreu um erro ao tentar baixar.` }, { quoted: info});
}
break;

case 'play':
case 'Play':
case 'p':
if (!q) return carisys.sendMessage(from, { text: `Informe o nome da música` }, { quoted: info });
try {
let Api = await fetchJson(`https://carisys.online/youtube/pesquisar?q=${encodeURIComponent(q)}`)
var nullo = 'Não encontrei resultados!'
var tation = `*꧁ ᴘᴇᴅɪᴅᴏ sᴏʟɪᴄɪᴛᴀᴅᴏ ᴘᴏʀ: @${sender.split('@')[0]} ꧂*\n
*➤ۣۜۜ͜͡🎬 ᴛɪᴛʟᴇ:* ${Api.resultado[0].title||nullo}\n
*➤ۣۜۜ͜͡💿 ᴠɪᴇᴡs:* ${Api.resultado[0].views||nullo}\n
*➤ۣۜۜ͜͡⏳ ᴅᴜʀᴀᴛɪᴏɴ:* ${Api.resultado[0].timestamp||nullo}\n
*➤ۣۜۜ͜͡📤 ᴘᴏsᴛᴇᴅ:* ${Api.resultado[0].ago||nullo}\n
*➤ۣۜۜ͜͡📃 ᴅᴇsᴄʀɪᴘᴛɪᴏɴ:* ${Api.resultado[0].description||nullo}\n
*1:28 ❍──────╼ 2:36 ↻ ⊲ Ⅱ ⊳ ↺*
*ᴠᴏʟᴜᴍᴇ : ▮▮▮▮▮▮▮▮▯▯▯*`

await carisys.sendMessage(from, {image: {url: Api.resultado[0].image}, caption: tation}, {quoted: info})
carisys.sendMessage(from, { text: `Baixando o áudio solicitado...` }, { quoted: info });
await carisys.sendMessage(from, {audio: {url: `https://carisys.online/api/downloads/youtube/mp3?url=${Api.resultado[0].url}`}, mimetype: "audio/mpeg"}, {quoted: info})
} catch (erro) {
console.error(erro);
carisys.sendMessage(from, { text: `Ocorreu um erro ao tentar baixar.` }, { quoted: info});
}
break;

case 'instagram': 
case 'Instagram':
if (!q) return carisys.sendMessage(from, { text: `Informe o url do vídeo` }, { quoted: info });
try {
carisys.sendMessage(from, { text: `Baixando o vídeo solicitado...` }, { quoted: info });
await carisys.sendMessage(from, {video: {url: `https://carisys.online/api/downloads/instagram/mp4?url=${encodeURIComponent(q)}`}, mimetype: "video/mp4"}, {quoted: info})
} catch (erro) {
console.error(erro);
carisys.sendMessage(from, { text: `Ocorreu um erro ao tentar baixar.` }, { quoted: info});
}
break

case 'tiktok':
case 'Tiktok':
case 'tiktokvideo':
case 'tiktok_video':
case 'tiktokmp4':
if (!q) return carisys.sendMessage(from, { text: `Informe o url do vídeo` }, { quoted: info });
try {
carisys.sendMessage(from, { text: `Baixando o vídeo solicitado...` }, { quoted: info });
await carisys.sendMessage(from, {video: {url:`https://carisys.online/api/downloads/tiktok/dl?url=${encodeURIComponent(q)}`}, mimetype: "video/mp4"}, {quoted: info})
} catch (erro) {
console.error(erro);
carisys.sendMessage(from, { text: `Ocorreu um erro ao tentar baixar.` }, { quoted: info});
}
break;

//FIM DAS CASES! 
default:
carisys.sendMessage(from, { text: `Comando não reconhecido. Tente novamente.` }, { quoted: info });
break;

//
}
}
});
//

carisys.ev.process(async (events) => {
if (events["connection.update"]) {
const update = events["connection.update"];
const { connection } = update;

if (connection === 'close') {
console.log(colors.red("Conexão encerrada, tentando reconectar..."));
CarisysBot();
} else if (connection === 'open') {
console.log(colors.green("Bot conectado com sucesso!"));
}
}

if (events["creds.update"]) {
await saveCreds();
}
});
}

CarisysBot().catch(error => {
console.log(colors.red("erro ao inicializar o bot: "), error);
});