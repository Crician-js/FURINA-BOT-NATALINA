const axios = require('axios')
const mimetype = require('mime-types')
const chalk = require('chalk')
const FormData = require("form-data");
const { downloadContentFromMessage, proto, delay, getContentType
} = require('@whiskeysockets/baileys')

const Random = Math.random(10)

const getExtension = async (type) => {
return await mimetype.extension(type)
}

const getFileBuffer = async (mediakey, MediaType) => { 
const stream = await downloadContentFromMessage(mediakey, MediaType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])
}
return buffer
}

module.exports = { getFileBuffer, getExtension, Random }