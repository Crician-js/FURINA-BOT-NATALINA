PURPLE='\033[1;31m'
while : 
do
echo "${PURPLE}CONECTANDO AGUARDE UM MOMENTO"
node commands.js
sleep 1
clear
done