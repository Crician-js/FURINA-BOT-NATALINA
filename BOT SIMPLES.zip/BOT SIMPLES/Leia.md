# Base simples com 3 comandos! 

# Comandos abaixo:
1°
```
Comando para instalar todos os módulos do node_modules:

npm install 

```
2° 
```
Comando para iniciar o bot:

Em host: npm start 
No termux: sh start.sh

```
